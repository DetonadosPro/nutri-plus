# Relatório da segunda revisão da curadoria TBCA

Segunda passada determinística sobre aliases, prioridade e nomes amigáveis. A fonte nutricional original e a primeira passada foram preservadas.

## Resumo

- Alimentos TBCA classificados: 5874.
- Prioridades: common=174, specific=3120, useful=2580.
- Confiança: high=483, low=455, medium=4936.
- Nomes amigáveis únicos: 5707; colisões: 133 grupos / 300 alimentos.
- Aliases: 10259 (máximo de 8 por alimento).
- Mudanças de classificação: 567; nomes alterados: 479.
- Aliases removidos: 7099; aliases adicionados: 1922.
- Transições: specific -> useful=236, useful -> specific=331.
- Correspondências TACO → TBCA: 513/597; 466 alimentos TBCA receberam sinal TACO.
- Possíveis duplicidades: 2319 pares.
- Confiança baixa: 455; sem classificação: 0.

## Amostras das mudanças

### 30 nomes naturalizados

- BRC0001B — Abóbora sem casca sem sementes crua → Abóbora crua — detalhes: Sem casca • Sem sementes • Brasil
- BRC0001E — Camarão sem casca cozido drenado sem óleo sem sal → Camarão cozido sem casca — detalhes: Sem óleo • Sem sal • Sem casca • Drenado • Brasil
- BRC0001F — Almôndega carne boi industrializada crua com sal → Almôndega bovina crua — detalhes: Com sal • Industrializado • Brasil
- BRC0001R — Bolo mistura para → Mistura para bolo — detalhes: Brasil
- BRC0002B — Abóbora cabotiá (japonesa) sem casca sem sementes crua → Abóbora cabotiá (japonesa) crua — detalhes: Sem casca • Sem sementes • Brasil
- BRC0002F — Almôndega carne ave industrializada crua com sal → Almôndega de frango crua — detalhes: Com sal • Industrializado • Brasil • Sadia
- BRC0003B — Abóbora Menina brasileira sem casca sem sementes crua → Abóbora Menina brasileira crua — detalhes: Sem casca • Sem sementes • Brasil
- BRC0003F — Almôndega carne boi crua com sal industrializada → Almôndega bovina crua — detalhes: Com sal • Industrializado • Brasil • Sadia
- BRC0004B — Abóbora Moranga sem casca sem sementes crua → Abóbora Moranga crua — detalhes: Sem casca • Sem sementes • Brasil
- BRC0004E — Caranguejo cozido sem óleo sem sal → Caranguejo cozido — detalhes: Sem óleo • Sem sal • Brasil
- BRC0004F — Almôndega carne boi industrializada frita com sal → Almôndega bovina frita — detalhes: Com sal • Industrializado • Brasil
- BRC0005B — Abóbora pescoço sem casca sem sementes crua → Abóbora pescoço crua — detalhes: Sem casca • Sem sementes • Brasil
- BRC0006E — Lagosta cozido sem óleo sem sal → Lagosta cozido — detalhes: Sem óleo • Sem sal • Brasil
- BRC0006T — Feijão jalo cozido (50% grão e 50% caldo) sem óleo sem sal → Feijão jalo cozido (50% grão e 50% caldo) — detalhes: Sem óleo • Sem sal • Brasil
- BRC0008U — Pupunha (palmito) fruto cozido sem óleo sem sal → Pupunha (palmito) fruto cozido — detalhes: Sem óleo • Sem sal • Brasil
- BRC0010T — Feijão rajado cozido (50% grão 50% caldo) sem óleo sem sal → Feijão rajado cozido (50% grão 50% caldo) — detalhes: Sem óleo • Sem sal • Brasil
- BRC0011E — Mexilhão cozido drenado sem óleo sem sal → Mexilhão cozido drenado — detalhes: Sem óleo • Sem sal • Drenado • Brasil
- BRC0011K — Chocolate pó → Chocolate em pó — detalhes: Brasil • Hikari
- BRC0014T — Feijão roxo cozido (50% grão e 50% caldo) sem óleo sem sal → Feijão roxo cozido (50% grão e 50% caldo) — detalhes: Sem óleo • Sem sal • Brasil
- BRC0017E — Ostra cozido sem óleo sem sal → Ostra cozido — detalhes: Sem óleo • Sem sal • Brasil
- BRC0017T — Grão-de- bico cozido drenado sem óleo sem sal → Grão-de- bico cozido drenado — detalhes: Sem óleo • Sem sal • Drenado • Brasil
- BRC0018F — Quarto dianteiro bovino sem gordura cozida sem óleo sem sal → Quarto dianteiro bovino sem gordura cozida — detalhes: Sem óleo • Sem sal • Brasil
- BRC0018T — Lentilha cozida drenada sem óleo sem sal → Lentilha cozida drenada — detalhes: Sem óleo • Sem sal • Drenado • Brasil
- BRC0019F — Quarto traseiro bovino sem gordura cozida sem óleo sem sal → Quarto traseiro bovino sem gordura cozida — detalhes: Sem óleo • Sem sal • Brasil
- BRC0020F — Quarto traseiro bovino com gordura grelhada sem óleo sem sal → Quarto traseiro bovino com gordura grelhada — detalhes: Sem óleo • Sem sal • Brasil
- BRC0021F — Quarto traseiro bovino sem gordura grelhada sem óleo sem sal → Quarto traseiro bovino sem gordura grelhada — detalhes: Sem óleo • Sem sal • Brasil
- BRC0022E — Corimbatá assado sem óleo sem sal → Corimbatá assado — detalhes: Sem óleo • Sem sal • Brasil
- BRC0023E — Corimbatá cozido sem óleo sem sal → Corimbatá cozido — detalhes: Sem óleo • Sem sal • Brasil
- BRC0024F — Cupim bovino assado sem óleo sem sal → Cupim bovino assado — detalhes: Sem óleo • Sem sal • Brasil
- BRC0024T — Ervilha fresca/seca cozida sem óleo sem sal → Ervilha fresca/seca cozida — detalhes: Sem óleo • Sem sal • Brasil

### 30 promoções specific → useful

- BRC0006T — Feijão jalo cozido (50% grão e 50% caldo) — Feijão, jalo, cozido (50% grão e 50% caldo), s/ óleo, s/ sal, Brasil
- BRC0014T — Feijão roxo cozido (50% grão e 50% caldo) — Feijão, roxo, cozido (50% grão e 50% caldo), s/ óleo, s/ sal, Brasil
- BRC0022F — Contra-filé bovino à milanesa (farinha de trigo ovo e farinha de rosca) frita em imersão sem sal — Carne, boi, contra-filé, à milanesa (farinha de trigo, ovo e farinha de rosca), frita em imersão, s/ sal
- BRC0028F — Capa de contra-filé bovino com gordura grelhada — Carne, boi, capa de contra-filé, c/ gordura, grelhada, s/ óleo, s/ sal, Brasil
- BRC0029F — Capa de contra-filé bovino sem gordura grelhada sem óleo com sal — Carne, boi, capa de contra-filé, s/ gordura, grelhada, s/ óleo, c/ sal, Brasil
- BRC0033F — Coxão duro (chã de fora) bovino cozido sem gordura — Carne, boi, coxão duro (chã de fora), s/ gordura, cozida, s/ óleo, s/ sal, Brasil
- BRC0042F — Miolo de alcatra bovino grelhado sem gordura — Carne, boi, miolo de alcatra, s/ gordura, grelhada, s/ óleo, s/ sal, Brasil
- BRC0044E — Bacalhau salgado dessalgado refogado (com óleo de soja cebola e alho) sem sal — Peixe, água salgada, bacalhau, salgado, dessalgado, refogado (c/ óleo de soja, cebola e alho), s/ sal, Brasil
- BRC0066E — Salmão filé com pele fresco grelhado — Peixe, água salgada, salmão, filé, c/ pele, fresco, grelhado, s/ óleo, s/ sal, Brasil
- BRC0077T — Lentilha cozida drenada com óleo de soja cebola e alho sem sal — Lentilha, cozida, drenada, c/ óleo de soja, cebola e alho, s/ sal, Brasil
- BRC0081T — Feijão guandu grão seco cozido (50% grão e 50% caldo) cebola e alho — Feijão, guandu, grão, seco, cozido (50% grão e 50% caldo), s/ óleo, cebola e alho, s/ sal, Brasil
- BRC0082T — Feijão guandu grão seco cozido (50% grão e 50% caldo) sem óleo cebola e alho com sal — Feijão, guandu, grão, seco, cozido (50% grão e 50% caldo), s/ óleo, cebola e alho, c/ sal
- BRC0090T — Feijão carioca cozido (50% grão e 50% caldo) com óleo cebola e alho sem sal — Feijão, carioca, cozido (50% grão e 50% caldo), c/ óleo, cebola e alho, s/ sal, Brasil
- BRC0099T — Feijão fradinho cozido (50% grão e 50% caldo) com óleo cebola e alho sem sal — Feijão, fradinho, cozido (50% grão e 50% caldo), c/ óleo, cebola e alho, s/ sal
- BRC0103C — Banana da terra frita (com óleo de soja) sem sal e açúcar — Banana, da terra, frita (c/ óleo de soja), s/ sal e açúcar, Brasil
- BRC0103F — Carne frango/galinha peito sem pele filé empanado cru sem sal — Carne, frango/galinha, peito, s/ pele, filé, empanado, cru, s/ sal (média de diferentes amostras), Brasil
- BRC0104T — Orelha-de-padre semente seca remolho em água cozida drenada sem óleo com sal — Orelha-de-padre, semente, seca, remolho em água, cozida, drenada, s/ óleo, c/ sal
- BRC0105C — Banana var. Narica (caturra ou dágua) à milanesa (farinha de rosca e ovo) frita em imersão (com óleo de soja) sem açúcar — Banana, var. Narica (caturra ou dágua), à milanesa (farinha de rosca* e ovo), frita em imersão (c/ óleo de soja), s/ açúcar, Brasil
- BRC0105T — Orelha-de-padre semente seca remolho em água cozida (água não descartada) sem óleo com sal — Orelha-de-padre, semente, seca, remolho em água, cozida (água não descartada), s/ óleo, c/ sal
- BRC0106C — Banana nanica à milanesa (farinha de trigo ovo e farinha de rosca) frita em imersão sem açúcar — Banana, nanica, à milanesa (farinha de trigo, ovo e farinha de rosca), frita em imersão, s/ açúcar
- BRC0107T — Feijão preto cozido (50% grão e 50% caldo) com óleo cebola e alho sem sal — Feijão, preto, cozido (50% grão e 50% caldo), c/ óleo, cebola e alho, s/ sal
- BRC0108E — Filé à milanesa (farinha de trigo ovo e farinha de rosca) frito (com óleo de soja) sem sal — Peixe, água doce, filé, à milanesa (farinha de trigo, ovo e farinha de rosca) frito (c/ óleo de soja), s/ sal (média de 7 espécies)
- BRC0109T — Bebida substituto do leite - extrato de soja natural com chocolate em pó sem açúcar — Bebida, substituto do leite - extrato de soja, natural, c/ chocolate em pó, s/ açúcar
- BRC0110B — Cheiro-verde (50% cebolinha verde 50% salsa) cozido — Cheiro-verde (50% cebolinha verde, 50% salsa), cozido, s/ óleo, s/ sal, Brasil
- BRC0110E — Filé refogado (com óleo cebola e alho) sem sal — Peixe, água doce, filé, refogado (c/ óleo, cebola e alho), s/ sal, Brasil (média de 7 espécies)
- BRC0113T — Orelha-de-padre semente seca remolho em água cozida drenada — Orelha-de-padre, semente, seca, remolho em água, cozida, drenada, s/ óleo, s/ sal
- BRC0116T — Orelha-de-padre semente seca remolho em água cozida (água não descartada) — Orelha-de-padre, semente, seca, remolho em água, cozida (água não descartada), s/ óleo, s/ sal
- BRC0129C — Suco natural laranja var. Pera mamão pera e maçã sem açúcar (sem diluição em água) — Suco natural, laranja var. Pera, mamão, pera e maçã, s/ açúcar (sem diluição em água), Brasil
- BRC0132C — Suco natural laranja var. Pera e morango com açúcar (sem dilução em água — Suco natural, laranja var. Pera e morango, c/ açúcar (sem dilução em água, Brasil
- BRC0142T — Bebida substituto do leite - extrato de soja natural com achocolatado em pó sem açúcar — Bebida, substituto do leite - extrato de soja, natural, c/ achocolatado em pó, s/ açúcar

### 30 aliases problemáticos removidos

- BRC0001S — Refeição composta por 80g arroz polido 60g feijão carioca 60g carne bovina refogada e 60g quibebe com óleo de soja com sal — alias removido: Arroz branco
- BRC0001S — Refeição composta por 80g arroz polido 60g feijão carioca 60g carne bovina refogada e 60g quibebe com óleo de soja com sal — alias removido: Arroz comum
- BRC0001S — Refeição composta por 80g arroz polido 60g feijão carioca 60g carne bovina refogada e 60g quibebe com óleo de soja com sal — alias removido: Feijão carioquinha
- BRC0001S — Refeição composta por 80g arroz polido 60g feijão carioca 60g carne bovina refogada e 60g quibebe com óleo de soja com sal — alias removido: Carne de boi
- BRC0001S — Refeição composta por 80g arroz polido 60g feijão carioca 60g carne bovina refogada e 60g quibebe com óleo de soja com sal — alias removido: Carne vermelha
- BRC0002S — Refeição composta por 80g arroz polido 60g feijão carioca e 60g batata inglesa sauté com óleo de soja com sal — alias removido: Arroz branco
- BRC0002S — Refeição composta por 80g arroz polido 60g feijão carioca e 60g batata inglesa sauté com óleo de soja com sal — alias removido: Arroz comum
- BRC0002S — Refeição composta por 80g arroz polido 60g feijão carioca e 60g batata inglesa sauté com óleo de soja com sal — alias removido: Batata comum
- BRC0002S — Refeição composta por 80g arroz polido 60g feijão carioca e 60g batata inglesa sauté com óleo de soja com sal — alias removido: Feijão carioquinha
- BRC0003S — Refeição composta por 80g arroz polido 60g fígado bovino com molho de tomate (molho sugo) e 60g purê de batata com óleo de soja com sal — alias removido: Molho sugo
- BRC0003S — Refeição composta por 80g arroz polido 60g fígado bovino com molho de tomate (molho sugo) e 60g purê de batata com óleo de soja com sal — alias removido: Arroz branco
- BRC0003S — Refeição composta por 80g arroz polido 60g fígado bovino com molho de tomate (molho sugo) e 60g purê de batata com óleo de soja com sal — alias removido: Arroz comum
- BRC0004G — Molho branco (molho bechamel) sem sal — alias removido: Molho branco (molho bechamel)
- BRC0004G — Molho branco (molho bechamel) sem sal — alias removido: Molho bechamel
- BRC0004S — Prato composto por 50 g de arroz polido e 50 g de feijão carioca com sal — alias removido: Prato composto por 50 g de arroz polido e 50 g de feijão carioca
- BRC0004S — Prato composto por 50 g de arroz polido e 50 g de feijão carioca com sal — alias removido: Arroz branco
- BRC0004S — Prato composto por 50 g de arroz polido e 50 g de feijão carioca com sal — alias removido: Prato composto por 50 g de arroz branco e 50 g de feijão carioca com sal
- BRC0004S — Prato composto por 50 g de arroz polido e 50 g de feijão carioca com sal — alias removido: Prato composto por 50 g de arroz branco e 50 g de feijão carioca
- BRC0004S — Prato composto por 50 g de arroz polido e 50 g de feijão carioca com sal — alias removido: Arroz comum
- BRC0004S — Prato composto por 50 g de arroz polido e 50 g de feijão carioca com sal — alias removido: Prato composto por 50 g de arroz comum e 50 g de feijão carioca com sal
- BRC0004S — Prato composto por 50 g de arroz polido e 50 g de feijão carioca com sal — alias removido: Prato composto por 50 g de arroz comum e 50 g de feijão carioca
- BRC0008G — Molho branco (molho bechamel) com sal — alias removido: Molho branco (molho bechamel)
- BRC0008G — Molho branco (molho bechamel) com sal — alias removido: Molho bechamel
- BRC0010D — Margarina com óleo hidrogenado (65% lipídeos) com sal — alias removido: Margarina hidrogenado (65% lipídeos)
- BRC0012D — Margarina com óleo interesterificado (65% lipídeos) com sal — alias removido: Margarina interesterificado (65% lipídeos)
- BRC0025J — Omelete com ovo de galinha com queijo parmesão sem sal — alias removido: Omelete com ovo de galinha com queijo parmesão
- BRC0025J — Omelete com ovo de galinha com queijo parmesão sem sal — alias removido: Omelete com ovo com queijo parmesão sem sal
- BRC0025J — Omelete com ovo de galinha com queijo parmesão sem sal — alias removido: Omelete com ovo com queijo parmesão
- BRC0026J — Omelete com ovo de galinha com queijo parmesão com sal — alias removido: Omelete com ovo de galinha com queijo parmesão
- BRC0026J — Omelete com ovo de galinha com queijo parmesão com sal — alias removido: Omelete com ovo com queijo parmesão com sal

## Exemplos atuais por prioridade

### common

- BRC0001T — Feijão carioca cozido — Feijão, carioca, cozido (50% grão e 50% caldo), s/ óleo, s/ sal, Brasil
- BRC0002A — Pão francês — Pão francês (cacetinho, de sal, média), de padaria, c/ farinha de trigo refinada, Brasil  (médias de diferentes amostras)
- BRC0007C — Banana nanica — Banana, var. Nanica (caturra ou dágua), in natura , Brasil
- BRC0018A — Arroz branco cozido — Arroz polido, cozido, s/ óleo, s/ sal, Brasil (média diferentes cultivares)
- BRC0020C — Laranja-pera — Laranja, Pera, in natura , Brasil
- BRC0020G — Iogurte natural — Iogurte, natural, Brasil (média de diferentes amostras)
- BRC0025F — Carne bovina moída cozida — Carne, bovina, moída (acém), cozida, drenada, s/ óleo, s/ sal, Brasil
- BRC0035B — Tomate cru — Tomate, cru, Brasil
- BRC0044G — Leite integral UHT — Leite, vaca, integral, fluído, UHT, Brasil (média de diferentes amostras)
- BRC0052G — Queijo minas frescal — Queijo, Minas, frescal, Brasil
- BRC0053B — Mandioca cozida — Mandioca (aipim, macaxeira), s/ casca, cozida, drenada, s/ óleo, s/ sal, Brasil
- BRC0114F — Peito de frango grelhado sem pele — Carne, frango, peito, s/ pele, grelhada, s/ óleo, s/ sal, Brasil
- BRC0116A — Macarrão cozido — Macarrão, farinha de trigo refinada, seco, cozido, drenado, s/ óleo, s/ sal, Brasil (média de diferentes amostras)
- BRC0117B — Batata inglesa cozida — Batata, inglesa, s/ casca, cozida, drenada, s/ óleo, c/ sal
- BRC0011C — Banana-prata — Banana, prata, in natura , Brasil
- BRC0059G — Queijo muçarela — Queijo, leite de vaca, muçarela (mussarela, muzarela, mozarela), Brasil (média de diferentes amostras)
- BRC0008T — Feijão preto cozido — Feijão, preto, cozido (50% grão e 50% caldo), s/ óleo, s/ sal, Brasil
- BRC0009C — Banana-maçã — Banana, maçã, in natura , Brasil
- BRC0010J — Ovo de galinha cozido — Ovo, galinha, inteiro, cozido, s/ sal, Brasil (média de várias amostras)
- BRC0043G — Leite integral pasteurizado — Leite, vaca, integral, fluído, pasteurizado, Brasil (média de diferentes amostras)
- BRC0047B — Cenoura cozida — Cenoura, s/ casca, cozida, drenada, s/ óleo, s/ sal, Brasil
- BRC0058G — Queijo minas padrão — Queijo, minas, padrão, Brasil
- BRC0063C — Maçã com casca — Maçã, Argentina, c/ casca, in natura , Brasil
- BRC0123B — Pão de queijo assado — Pão, de queijo, industrializado, assado, Brasil
- BRC0194F — Peito de frango cozido sem pele — Carne, frango, peito, s/ pele, cozida, drenada, s/ óleo, s/ sal
- BRC0008C — Banana-da-terra — Banana, da terra, in natura , Brasil
- BRC0016A — Arroz integral cozido — Arroz, integral, cozido, s/ óleo, s/ sal, Brasil
- BRC0022G — Iogurte natural desnatado — Iogurte, natural, desnatado, Brasil
- BRC0036G — Leite desnatado — Leite, vaca, desnatado, fluído (média de diferentes amostras), Brasil
- BRC0047F — Picanha bovina grelhada com gordura — Carne, boi, picanha, c/ gordura, grelhada, s/ sal, Brasil

### useful

- BRC0052J — Ovo de codorna cozido — Ovo, codorna, inteiro, cozido, s/ sal, Brasil
- BRC0001D — Azeite de dendê — Azeite, dendê, Brasil
- BRC0001G — Bebida láctea — Bebida láctea (média de diferentes sabores), Brasil
- BRC0001H — Bebida isotônica (diversos sabores) — Bebida isotônica (diversos sabores), Brasil
- BRC0001K — Achocolatado em pó — Achocolatado, em pó (média diferentes amostras), Brasil
- BRC0001L — Café torrado em pó — Café, torrado, em pó, Brasil
- BRC0001N — Chocolate ao leite dietético — Chocolate, ao leite, dietético, Brasil
- BRC0002B — Abóbora cabotiá (japonesa) crua — Abóbora, cabotian (japonesa), s/ casca, s/sementes, crua, Brasil
- BRC0002D — Azeite de oliva — Azeite, oliva, Brasil
- BRC0003B — Abóbora Menina brasileira crua — Abóbora, Menina brasileira, s/ casca, s/ sementes, crua, Brasil
- BRC0003C — Açaí polpa — Açaí, polpa (média de amostras), Brasil
- BRC0003E — Camarão Sete Barbas sem cabeça com casca frito sem sal — Crustáceo, camarão, Sete Barbas, sem cabeça, com casca, frito, s/ sal, Brasil
- BRC0003J — Ovo de codorna inteiro cru — Ovo, codorna, inteiro, cru, Brasil
- BRC0003U — Castanha-do-brasil crua — Castanha-do-brasil, crua, Brasil
- BRC0004B — Abóbora Moranga crua — Abóbora, Moranga, s/ casca, s/ sementes, crua, Brasil
- BRC0004C — Acerola madura polpa — Acerola, madura, polpa, Brasil
- BRC0004E — Caranguejo cozido — Crustáceo, caranguejo, cozido, s/ óleo, s/ sal, Brasil
- BRC0004J — Ovo de galinha clara cozida/10 min sem sal — Ovo, galinha, clara, cozida/10 min, s/ sal, Brasil
- BRC0004T — Feijão fradinho (corda caupi massacar) cru — Feijão, fradinho (corda, caupi, massacar), cru, Brasil
- BRC0005B — Abóbora pescoço crua — Abóbora, pescoço, s/ casca, s/ sementes, crua, Brasil
- BRC0005K — Açúcar cristal — Açúcar, cristal, Brasil
- BRC0005T — Feijão guandu grão cru — Feijão, guandu, grão, cru, Brasil
- BRC0006A — Milho verde grão cru — Milho, verde, grão, cru, Brasil (média de diferentes amostras)
- BRC0006B — Abobrinha italiana com casca crua — Abobrinha, italiana, c/ casca, crua, Brasil
- BRC0006D — Manteiga sem sal — Manteiga, s/ sal, Brasil
- BRC0006F — Apresuntado cozido — Apresuntado, cozido (média de diferentes marcas), Brasil
- BRC0006K — Açúcar mascavo — Açúcar, mascavo, Brasil
- BRC0006L — Fermento químico em pó — Fermento, químico, em pó, Brasil
- BRC0006T — Feijão jalo cozido (50% grão e 50% caldo) — Feijão, jalo, cozido (50% grão e 50% caldo), s/ óleo, s/ sal, Brasil
- BRC0006U — Linhaça semente — Linhaça, semente, Brasil

### specific

- BRC0004G — Molho branco (molho bechamel) sem sal — Molho branco (molho bechamel), s/ sal, Brasil
- BRC0008G — Molho branco (molho bechamel) com sal — Molho branco (molho bechamel), c/ sal, Brasil
- BRC0010D — Margarina com óleo hidrogenado (65% lipídeos) com sal — Margarina, c/ óleo hidrogenado (65% lipídeos), c/ sal, Brasil
- BRC0012D — Margarina com óleo interesterificado (65% lipídeos) com sal — Margarina, c/ óleo interesterificado (65% lipídeos), c/ sal, Brasil
- BRC0016G — Iogurte integral salada de frutas — Iogurte, integral, salada de frutas, Brasil
- BRC0025J — Omelete com ovo de galinha com queijo parmesão sem sal — Omelete, c/ ovo de galinha, c/ queijo parmesão, s/ sal
- BRC0026J — Omelete com ovo de galinha com queijo parmesão com sal — Omelete, c/ ovo de galinha, c/ queijo parmesão, c/ sal
- BRC0027J — Ovo de galinha mexido com margarina com sal — Ovo, galinha, mexido, c/ margarina, c/ sal, Brasil
- BRC0028J — Ovo de galinha inteiro frito (com óleo de soja) com sal — Ovo, galinha, inteiro, frito (c/ óleo de soja*), c/ sal, Brasil
- BRC0029L — Mostarda molho — Mostarda, molho (dado importado)
- BRC0030J — Omelete com ovo de galinha com queijo muçarela sem sal — Omelete, c/ ovo de galinha, c/ queijo muçarela, s/ sal, Brasil
- BRC0030L — Catchup tomate molho — Catchup, tomate, molho (dado importado)
- BRC0031D — Maionese molho com ovos industrializado — Maionese, molho, c/ ovos, industrializado, Brasil
- BRC0031J — Omelete com ovo de galinha com queijo muçarela com sal — Omelete, c/ ovo de galinha, c/ queijo muçarela, c/ sal
- BRC0031L — Molho para salada com suco de limão artesanal com sal — Molho para salada, c/ suco de limão, artesanal, c/ sal, Brasil
- BRC0032K — Torta mousse — Torta, mousse (média de diversos sabores), Brasil
- BRC0032L — Molho para salada com vinagre de maçã artesanal com sal — Molho para salada, c/ vinagre de maçã, artesanal, c/ sal, Brasil
- BRC0032U — Bebida substituto do leite bebida vegetal à base de amêndoa com chocolate em pó com açúcar — Bebida, substituto do leite, bebida vegetal à base de amêndoa, c/ chocolate em pó, c/ açúcar
- BRC0033L — Molho para salada tipo Caesar artesanal com sal — Molho para salada, tipo Caesar, artesanal, c/ sal, Brasil
- BRC0036L — Molho tártaro artesanal com sal — Molho tártaro, artesanal, c/ sal, Brasil
- BRC0037L — Molho inglês — Molho, inglês (dado importado)
- BRC0038L — Molho pimenta tabasco — Molho, pimenta, tabasco (dado importado)
- BRC0039L — Molho holandês com sal caseiro — Molho, holandês, c/ sal, caseiro
- BRC0040L — Molho holandês sem sal caseiro — Molho, holandês, s/ sal, caseiro
- BRC0041L — Molho rosê caseiro com sal — Molho rosê, caseiro, c/ sal
- BRC0042L — Molho de iogurte picante com sal caseiro — Molho de iogurte picante, c/ sal, caseiro
- BRC0043A — Biscoito doce recheado sabores diversos — Biscoito, doce, recheado, sabores diversos (média de diferentes sabores), Brasil
- BRC0043H — Café com leite (meio a meio) com açúcar — Bebida, café, c/ leite (meio a meio), c/ açúcar
- BRC0043L — Molho de iogurte picante sem sal caseiro — Molho de iogurte picante, s/ sal, caseiro
- BRC0044J — Ovos Benedict com lombo canadense com sal — Ovos Benedict, c/ lombo canadense, c/ sal

## Buscas antes/depois

### arroz

Primeira passada: Arroz branco cozido [common] (BRC0018A); Arroz integral cozido [common] (BRC0016A); Arroz branco cru [common] (BRC0001A); Arroz integral cru [common] (BRC0017A); Arroz carreteiro com arroz polido e charque (carne seca jaba) sem sal [common] (BRC0187A); Arroz carreteiro com arroz polido e charque (carne seca jaba) com sal [common] (BRC0887A); Arroz creme pó cru [useful] (BRC0792A); Arroz creme cozido sem tempero [useful] (BRC0012A); Arroz de leite [useful] (BRC0805A); Arroz de leite [useful] (BRC0997A)

Segunda passada: Arroz branco cozido [common] (BRC0018A); Arroz integral cozido [common] (BRC0016A); Arroz branco cru [common] (BRC0001A); Arroz integral cru [common] (BRC0017A); Arroz carreteiro com arroz polido e charque (carne seca jaba) sem sal [common] (BRC0187A); Arroz carreteiro com arroz polido e charque (carne seca jaba) com sal [common] (BRC0887A); Arroz creme pó cru [useful] (BRC0792A); Arroz creme cozido sem tempero [useful] (BRC0012A); Arroz de leite [useful] (BRC0805A); Arroz de leite [useful] (BRC0997A)

### feijão

Primeira passada: Feijão carioca cozido [common] (BRC0001T); Feijão preto cozido [common] (BRC0008T); Feijão carioca cru [common] (BRC0002T); Feijão preto cru [common] (BRC0009T); Feijão-fradinho cozido [common] (BRC0003T); Feijão branco cozido [common] (BRC0028T); Feijão jalo cru [useful] (BRC0007T); Feijão roxo cru [useful] (BRC0015T); Feijão broto cru [useful] (BRC0074B); Feijão rajado cru [useful] (BRC0011T)

Segunda passada: Feijão carioca cozido [common] (BRC0001T); Feijão preto cozido [common] (BRC0008T); Feijão carioca cru [common] (BRC0002T); Feijão preto cru [common] (BRC0009T); Feijão-fradinho cozido [common] (BRC0003T); Feijão branco cozido [common] (BRC0028T); Feijão jalo cru [useful] (BRC0007T); Feijão roxo cru [useful] (BRC0015T); Feijão broto cru [useful] (BRC0074B); Feijão rajado cru [useful] (BRC0011T)

### frango

Primeira passada: Peito de frango grelhado sem pele [common] (BRC0114F); Peito de frango cozido sem pele [common] (BRC0194F); Peito de frango assado sem pele [common] (BRC0113F); Peito de frango cru sem pele [common] (BRC0133F); Frango com açafrão (cúrcuma) sem sal [useful] (BRC0226F); Frango xadrez com molho shoyu [useful] (BRC0554F); Frango xadrez sem molho shoyu sem sal [useful] (BRC0555F); Frango ao molho pardo (frango de cabidela) [useful] (BRC0570F); Frango com açafrão (cúrcuma) com sal [specific] (BRC0915F); Lasanha peito de frango caseira [common] (BRC0558A)

Segunda passada: Peito de frango grelhado sem pele [common] (BRC0114F); Peito de frango cozido sem pele [common] (BRC0194F); Peito de frango assado sem pele [common] (BRC0113F); Peito de frango cru sem pele [common] (BRC0133F); Frango com açafrão (cúrcuma) sem sal [useful] (BRC0226F); Frango xadrez com molho shoyu [specific] (BRC0554F); Frango com açafrão (cúrcuma) com sal [specific] (BRC0915F); Frango xadrez sem molho shoyu sem sal [specific] (BRC0555F); Frango ao molho pardo (frango de cabidela) [specific] (BRC0570F); Lasanha peito de frango caseira [common] (BRC0558A)

### ovo

Primeira passada: Ovo de galinha cozido [common] (BRC0010J); Ovo mexido sem óleo e sem sal [common] (BRC0065J); Ovo de galinha frito [common] (BRC0015J); Ovo de galinha cru [common] (BRC0011J); Ovo de codorna cozido [useful] (BRC0052J); Ovo de codorna inteiro cru [useful] (BRC0003J); Ovo de galinha gema cozida/10 min sem sal [useful] (BRC0007J); Ovo de galinha clara cozida/10 min sem sal [useful] (BRC0004J); Ovo de pata gema crua [useful] (BRC0019J); Ovo de pata clara crua [useful] (BRC0018J)

Segunda passada: Ovo de galinha cozido [common] (BRC0010J); Ovo mexido sem óleo e sem sal [common] (BRC0065J); Ovo de galinha frito [common] (BRC0015J); Ovo de galinha cru [common] (BRC0011J); Ovo de codorna cozido [useful] (BRC0052J); Ovo de codorna inteiro cru [useful] (BRC0003J); Ovo de galinha gema cozida/10 min sem sal [useful] (BRC0007J); Ovo de galinha clara cozida/10 min sem sal [useful] (BRC0004J); Ovo de pata gema crua [useful] (BRC0019J); Ovo de pata clara crua [useful] (BRC0018J)

### leite

Primeira passada: Leite integral UHT [common] (BRC0044G); Leite integral pasteurizado [common] (BRC0043G); Leite desnatado [common] (BRC0036G); Leite desnatado UHT [common] (BRC0070G); Leite semidesnatado UHT [common] (BRC0046G); Leite fermentado [useful] (BRC0031G); Leite integral em pó [useful] (BRC0039G); Leite desnatado em pó [useful] (BRC0038G); Leite cabra integral fluido [useful] (BRC0028G); Leite condensado com açúcar enlatado [useful] (BRC0030G)

Segunda passada: Leite integral UHT [common] (BRC0044G); Leite integral pasteurizado [common] (BRC0043G); Leite desnatado [common] (BRC0036G); Leite desnatado UHT [common] (BRC0070G); Leite semidesnatado UHT [common] (BRC0046G); Leite fermentado [useful] (BRC0031G); Leite integral em pó [useful] (BRC0039G); Leite desnatado em pó [useful] (BRC0038G); Leite cabra integral fluido [useful] (BRC0028G); Leite condensado com açúcar enlatado [useful] (BRC0030G)

### banana

Primeira passada: Banana nanica [common] (BRC0007C); Banana-prata [common] (BRC0011C); Banana-maçã [common] (BRC0009C); Banana-da-terra [common] (BRC0008C); Banana in natura [common] (BRC0006C); Banana-ouro [common] (BRC0010C); Banana doce em barra [useful] (BRC0094C); Banana Figo in natura [useful] (BRC0093C); Banana pacova in natura [useful] (BRC0092C); Banana passa [useful] (BRC0313C)

Segunda passada: Banana nanica [common] (BRC0007C); Banana-prata [common] (BRC0011C); Banana-maçã [common] (BRC0009C); Banana-da-terra [common] (BRC0008C); Banana in natura [common] (BRC0006C); Banana-ouro [common] (BRC0010C); Banana doce em barra [useful] (BRC0094C); Banana Figo in natura [useful] (BRC0093C); Banana pacova in natura [useful] (BRC0092C); Banana passa [useful] (BRC0313C)

### carne

Primeira passada: Carne bovina moída cozida [common] (BRC0025F); Picanha bovina grelhada com gordura [common] (BRC0047F); Contrafilé bovino grelhado [common] (BRC0023F); Costela bovina assada [common] (BRC0032F); Patinho bovino grelhado [common] (BRC0045F); Filé-mignon bovino grelhado [common] (BRC0036F); Maminha bovina grelhada [common] (BRC0041F); Coxão mole bovino cozido [common] (BRC0034F); Acém bovino cozido [common] (BRC0026F); Carne rã crua [useful] (BRC0986F)

Segunda passada: Carne bovina moída cozida [common] (BRC0025F); Picanha bovina grelhada com gordura [common] (BRC0047F); Contrafilé bovino grelhado [common] (BRC0023F); Costela bovina assada [common] (BRC0032F); Patinho bovino grelhado [common] (BRC0045F); Filé-mignon bovino grelhado [common] (BRC0036F); Maminha bovina grelhada [common] (BRC0041F); Coxão mole bovino cozido [common] (BRC0034F); Acém bovino cozido [common] (BRC0026F); Carne frango/galinha peito sem pele filé empanado cru sem sal [useful] (BRC0103F)

### pão

Primeira passada: Pão francês [common] (BRC0002A); Pão de queijo assado [common] (BRC0123B); Pão integral [common] (BRC0149A); Pão de forma tradicional [common] (BRC0003A); Pão bisnaguinha [common] (BRC0148A); Pão milho forma [useful] (BRC0146A); Pão de queijo industrializado cru [useful] (BRC0094B); Pão trigo aveia com fibras forma diet [useful] (BRC0032N); Pão com farinha de trigo refinada sovado [useful] (BRC0160A); Pão com farinha de trigo refinada glúten forma [useful] (BRC0145A)

Segunda passada: Pão francês [common] (BRC0002A); Pão de queijo assado [common] (BRC0123B); Pão integral [common] (BRC0149A); Pão de forma tradicional [common] (BRC0003A); Pão bisnaguinha [common] (BRC0148A); Pão milho forma [useful] (BRC0146A); Pão de queijo industrializado cru [useful] (BRC0094B); Pão trigo aveia com fibras forma diet [useful] (BRC0032N); Pão com farinha de trigo refinada sovado [useful] (BRC0160A); Pão com farinha de trigo refinada glúten forma [useful] (BRC0145A)

### batata

Primeira passada: Batata inglesa cozida [common] (BRC0117B); Batata inglesa frita [common] (BRC0048B); Batata-doce assada [common] (BRC0302B); Batata-baroa cozida [common] (BRC0054B); Batata inglesa crua [common] (BRC0013B); Batata-doce crua [common] (BRC0012B); Batata inglesa chips frita com sal [useful] (BRC0049B); Batata baroa (mandioquinha batata salsa) sem casca crua [useful] (BRC0028B); Batata doce sem casca cozida drenada sem óleo sem sal [useful] (BRC0042B); Batata inglesa sem casca cozida drenada sem óleo sem sal [useful] (BRC0041B)

Segunda passada: Batata inglesa cozida [common] (BRC0117B); Batata inglesa frita [common] (BRC0048B); Batata-doce assada [common] (BRC0302B); Batata-baroa cozida [common] (BRC0054B); Batata inglesa crua [common] (BRC0013B); Batata-doce crua [common] (BRC0012B); Batata inglesa chips frita com sal [useful] (BRC0049B); Batata doce sem casca cozida drenada [useful] (BRC0042B); Batata inglesa sem casca cozida drenada [useful] (BRC0041B); Batata baroa (mandioquinha batata salsa) sem casca crua [useful] (BRC0028B)

### queijo

Primeira passada: Queijo minas frescal [common] (BRC0052G); Queijo muçarela [common] (BRC0059G); Queijo minas padrão [common] (BRC0058G); Queijo prato [common] (BRC0064G); Queijo coalho [common] (BRC0048G); Queijo parmesão ralado [common] (BRC0061G); Queijo muçarela de vaca e búfala [common] (BRC0047G); Ricota [common] (BRC0051G); Queijo requeijão [useful] (BRC0066G); Queijo pasteurizado [useful] (BRC0062G)

Segunda passada: Queijo minas frescal [common] (BRC0052G); Queijo muçarela [common] (BRC0059G); Queijo minas padrão [common] (BRC0058G); Queijo prato [common] (BRC0064G); Queijo coalho [common] (BRC0048G); Queijo parmesão ralado [common] (BRC0061G); Queijo muçarela de vaca e búfala [common] (BRC0047G); Ricota [common] (BRC0051G); Queijo requeijão [useful] (BRC0066G); Queijo pasteurizado [useful] (BRC0062G)

### camarão

Primeira passada: Camarão à baiana sem sal [useful] (BRC0083E); Camarão Sete Barbas sem cabeça com casca frito sem sal [useful] (BRC0003E); Camarão Pitu cru [useful] (BRC0259E); Camarão sem casca cru [useful] (BRC0002E); Camarão à baiana com sal [useful] (BRC0393E); Camarão com chuchu sem sal [useful] (BRC0287E); Camarão na moranga com sal [useful] (BRC0294E); Camarão na moranga sem sal [useful] (BRC0295E); Camarão com legumes sem sal [useful] (BRC0291E); Camarão Pitu frito sem sal [useful] (BRC0260E)

Segunda passada: Camarão à baiana sem sal [useful] (BRC0083E); Camarão Sete Barbas sem cabeça com casca frito sem sal [useful] (BRC0003E); Camarão Pitu cru [useful] (BRC0259E); Camarão sem casca cru [useful] (BRC0002E); Camarão à baiana com sal [useful] (BRC0393E); Camarão cozido sem casca [useful] (BRC0001E); Camarão com chuchu sem sal [useful] (BRC0287E); Camarão na moranga com sal [useful] (BRC0294E); Camarão na moranga sem sal [useful] (BRC0295E); Camarão com legumes sem sal [useful] (BRC0291E)

### abóbora

Primeira passada: Abóbora Moranga sem casca sem sementes crua [useful] (BRC0004B); Abóbora pescoço sem casca sem sementes crua [useful] (BRC0005B); Abóbora cabotiá (japonesa) sem casca sem sementes crua [useful] (BRC0002B); Abóbora Menina brasileira sem casca sem sementes crua [useful] (BRC0003B); Abóbora cabotiá (japonesa) sem casca cozida drenada sem óleo sem sal [useful] (BRC0059B); Abóbora paulista crua [useful] (BRC0064B); Abóbora sem casca sem sementes crua [useful] (BRC0001B); Abóbora moranga refogada (com óleo cebola e alho) sem sal [useful] (BRC0101B); Abóbora moranga sem casca sem semente assada sem óleo sem sal [useful] (BRC0354B); Abóbora moranga sem casca sem semente assada sem óleo com sal [useful] (BRC0355B)

Segunda passada: Abóbora Moranga crua [useful] (BRC0004B); Abóbora pescoço crua [useful] (BRC0005B); Abóbora cabotiá (japonesa) crua [useful] (BRC0002B); Abóbora Menina brasileira crua [useful] (BRC0003B); Abóbora cabotiá (japonesa) cozida drenada [useful] (BRC0059B); Abóbora crua [useful] (BRC0001B); Abóbora paulista crua [useful] (BRC0064B); Abóbora moranga assada [useful] (BRC0354B); Abóbora moranga cozida drenada [useful] (BRC0165B); Abóbora pescoço cozida drenada [useful] (BRC0227B)

### chocolate

Primeira passada: Chocolate meio amargo [useful] (BRC0054K); Chocolate ao leite dietético [useful] (BRC0001N); Chocolate ao leite com castanha do Brasil [useful] (BRC0052K); Chocolate amargo [useful] (BRC0038K); Chocolate branco [useful] (BRC0053K); Chocolate bombom [useful] (BRC0093K); Chocolate ao leite [useful] (BRC0046K); Chocolate granulado [useful] (BRC0194K); Chocolate em pó solúvel [useful] (BRC0094K); Chocolate ao leite com avelã [useful] (BRC0184K)

Segunda passada: Chocolate meio amargo [useful] (BRC0054K); Chocolate ao leite dietético [useful] (BRC0001N); Chocolate ao leite com castanha do Brasil [useful] (BRC0052K); Chocolate amargo [useful] (BRC0038K); Chocolate branco [useful] (BRC0053K); Chocolate bombom [useful] (BRC0093K); Chocolate ao leite [useful] (BRC0046K); Chocolate granulado [useful] (BRC0194K); Chocolate em pó solúvel [useful] (BRC0094K); Chocolate ao leite com avelã [useful] (BRC0184K)

### café

Primeira passada: Café torrado em pó [useful] (BRC0001L); Café infusão 10% sem açúcar [useful] (BRC0007H); Café solúvel em pó [useful] (BRC0051L); Café espresso sem açúcar [useful] (BRC0173H); Café infusão 10% com açúcar [useful] (BRC0042H); Café descafeinado torrado moído [useful] (BRC0044L); Café infusão 6% - suave sem açúcar [useful] (BRC0060H); Café infusão 6% - suave com açúcar [useful] (BRC0061H); Café infusão 8% - médio sem açúcar [useful] (BRC0062H); Café infusão 8% - médio com açúcar [useful] (BRC0063H)

Segunda passada: Café torrado em pó [useful] (BRC0001L); Café infusão 10% sem açúcar [useful] (BRC0007H); Café solúvel em pó [useful] (BRC0051L); Café espresso sem açúcar [useful] (BRC0173H); Café infusão 10% com açúcar [useful] (BRC0042H); Café descafeinado torrado moído [useful] (BRC0044L); Café infusão 6% - suave sem açúcar [useful] (BRC0060H); Café infusão 6% - suave com açúcar [useful] (BRC0061H); Café infusão 8% - médio sem açúcar [useful] (BRC0062H); Café infusão 8% - médio com açúcar [useful] (BRC0063H)

### peixe

Primeira passada: Peixe à parmegiana [useful] (BRC0242E); Peixe agua salgada merluza frito oleo soja sal [useful] (BRC0194E); Corvina cru [useful] (BRC0019E); Pintado cru [useful] (BRC0029E); Atum cru [useful] (BRC0042E); Corimba cru [useful] (BRC0086E); Porquinho cru [useful] (BRC0059E); Tucunaré filé cru [useful] (BRC0032E); Pescada filé cru [useful] (BRC0055E); Merluza filé cru [useful] (BRC0063E)

Segunda passada: Peixe à parmegiana [useful] (BRC0242E); Peixe agua salgada merluza frito oleo soja sal [useful] (BRC0194E); Corvina cru [useful] (BRC0019E); Pintado cru [useful] (BRC0029E); Atum cru [useful] (BRC0042E); Corimba cru [useful] (BRC0086E); Porquinho cru [useful] (BRC0059E); Tucunaré filé cru [useful] (BRC0032E); Pescada filé cru [useful] (BRC0055E); Merluza filé cru [useful] (BRC0063E)

## Casos para revisão humana

Os 455 itens de confiança baixa permanecem pesquisáveis e estão identificados no artefato. Colisões e pares semelhantes estão no relatório JSON completo; nenhum registro foi excluído ou mesclado.

## Reprodutibilidade

- SHA-256 da fonte TBCA: `25bf7e2e60763e404be42b61011fc99256c6f944c43ed93b23ec4b14ec7d53a7`.
- Fingerprint da curadoria: `48ca573cf5e450b8e8af3378c1fdd0ef5e5f6b07d23eeda77bd3cff693f7f494`.
- Regerar: `npm run curation:generate`.
- Validar sem escrever no banco: `npm run curation:check`.
- Importar localmente com invariantes: `npm run curation:import`.
- Auditar banco e performance: `npm run curation:audit`.

## Integridade local verificada

A segunda passada foi importada duas vezes consecutivas no banco local. As duas transações produziram os mesmos valores antes e depois:

- 5.874 TBCA ativos e 597 TACO inativos.
- 8.316 medidas, IDs de 9 a 22.616.
- Fingerprint das medidas: `7d7dd61b1b51a5352299d739c1dde9bed8d080beca2d64556a184cd3d5742f59`.
- Fingerprint de identidade das medidas: `3705f681ca9ef0dac9fdf133cc256396e4f3047725abe0b16cef500d7fd25a4e`.
- Histórico: 37 lançamentos, 4.244 g, 0 snapshots; fingerprint `0a41cae916dbf37dc44aa2f6ffda83887bb2f3b848dda70c1e8aaf7d1d17a132`.
- Identidade/códigos dos alimentos: `c736b4d473fdb20bd56fa90d5c6c92add5a3db24ef20f037f1b999de353521f6`.
- Nutrientes: `7c663b29885bff52dda27adf5d295126b67d68dbb79ea7965d011845ac0f55db`.
- Relações e IDs de medidas: `fcf3f6acdd315555053596063ac9ead165a758a2d1b2fcddc668c5ebc918472e`.
- Histórico e snapshots: `019666543e65d1932532d9fd1910b308480a1c155849e675680dcb5d28e50335`.

Nenhuma publicação em produção foi feita.
