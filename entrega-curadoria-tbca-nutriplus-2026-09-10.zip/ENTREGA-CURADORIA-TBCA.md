# Pacote da curadoria TBCA do Nutri+

Este pacote contém os arquivos criados e modificados para implementar a camada determinística de curadoria e busca dos 5.874 alimentos TBCA, incluindo a segunda passada de qualidade.

## Conteúdo principal

- artefato completo da curadoria e relatório estruturado;
- overrides humanos por `source_code`;
- regras determinísticas, importador transacional e auditoria;
- migration PostgreSQL;
- ranking da API e apresentação no frontend;
- testes automatizados;
- documentação e relatório com exemplos antes/depois.
- cópia imutável dos artefatos da primeira passada para comparação e rastreabilidade.

## Dependências não incluídas

A fonte nutricional `backend/data/tbca/tbca completa normalizada.json` não foi criada nesta tarefa e não está duplicada no ZIP. Ela permanece no projeto Nutri+ e é validada pelo SHA-256 `25bf7e2e60763e404be42b61011fc99256c6f944c43ed93b23ec4b14ec7d53a7`.

Os dados nutricionais, medidas e histórico também não estão no pacote. Nenhum deles foi alterado pela curadoria.

## Resultados validados

- 5.874 TBCA ativos e classificados;
- 597 TACO inativos;
- 8.316 medidas preservadas;
- 174 `common`, 2.580 `useful` e 3.120 `specific`;
- 10.259 aliases atuais;
- 567 classificações alteradas: 236 `specific → useful` e 331 `useful → specific`;
- 479 nomes naturalizados, 7.099 aliases removidos e 1.922 adicionados;
- 513 correspondências TACO para TBCA;
- 115 testes aprovados, TypeScript, lint e build aprovados;
- fingerprints de identidade, nutrientes, medidas e histórico invariáveis em duas importações locais consecutivas;
- nenhuma publicação em produção.

Leia primeiro `docs/tbca-search-curation.md` e `docs/tbca-curation-report.md`.
